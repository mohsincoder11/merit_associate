<?php

namespace App\Http\Controllers\Setting;
use App\Models\Setting\UserRole;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UserRoleController extends Controller
{
    public function index()
    {
        $user_role_all=UserRole::all();
        return view('Setting.user_role',compact('user_role_all'));
    }

    public function insert(request $request)
    {
       $store= new UserRole;
       $store->role_name=$request->get('role_name');
       $store->page_name=$request->get('page_name');
       $store->save();
       return redirect(route('user_role'))->with(['success' => true, 'message' => 'Data Successfully Submitted !']);

    }

    public function delete(Request $request)  
    {  
      $data=UserRole::where('id',$request->id)->delete();   
        return redirect(route('user_role'))->with(['success' => true, 'message' => 'Data Deleted Successfully  !']); 
    } 

    public function edit(request $request)
    {
   // echo json_encode($request->all());
      $data1=UserRole::find($request->id);
      $user_role_all=UserRole::all();

     
    //   $ass_data=AssociatesBank::all();
      // echo json_encode($data1);
      // exit();
    return view('Setting.edit_user_role',['edit_data'=>$data1,'user_role_all'=>$user_role_all]);
    }

    public function update(Request $request)
    {
      //dd($request->all());
   $data =UserRole::find($request->id);
   //echo json_encode($data);
       // exit();
       $data->role_name=$request->get('role_name');
       $data->page_name=$request->get('page_name');
   $data->save();
   return redirect(route('user_role'))->with(['success' => true, 'message' => 'Data Update Successfully  !']);
  }

}
