<?php

namespace App\Http\Controllers\FieldExecutive;

use App\Http\Controllers\Controller;
use App\Models\Admin\Add_news;
use App\Models\FieldExecutive\New_Valuer;
use App\Models\Masters\Property;
use App\Models\Masters\Category;
use App\Models\Masters\EmployeeRegistration;
use App\Models\Masters\Location;
use App\Models\Masters\Tags;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Models\Masters\AssociatesBank;
use App\Models\Masters\Products;
use App\Models\Masters\Area;

class New_ValuerController extends Controller
{
    public function index( $id)
    {
        
        $new = New_Valuer :: leftjoin('propertys','propertys.id','=','new_valuer.property_type_id') 
        ->leftjoin('categorys','categorys.id','=','new_valuer.category_id') 
        ->rightjoin('tags','tags.id','=','new_valuer.tag_id')
        ->leftjoin('locations','locations.id','=','new_valuer.location_id')
        ->select('new_valuer.*','categorys.category','tags.tag','locations.locations','propertys.property')
        ->get();

        // echo json_encode($new);
        // exit();

       


//join for accordain
    //     $add_new_all=Add_news::leftjoin('locations','locations.id','=','add_news.location_id')
    //       ->leftjoin('areas','areas.id','=','add_news.area_id')
    //       ->leftjoin('associatesbanks','associatesbanks.id','=','add_news.associatesbanks_id')
    //       ->leftjoin('products','products.id','=','add_news.product_id')
    // ->leftjoin('employee_registraions as emp1','emp1.id','=','add_news.field_executive_id')
    // ->leftjoin('employee_registraions as emp2','emp2.id','=','add_news.assistant_valuer_id')
    // ->leftjoin('employee_registraions as emp3','emp3.id','=','add_news.technical_manager_id')
    // ->leftjoin('employee_registraions as emp4','emp4.id','=','add_news.technical_head_id')
    //  ->select('add_news.*','locations.locations','associatesbanks.bankname','products.products','areas.area','emp1.name as field_executive',
    //       'emp2.name as  assistant_valuer','emp3.name as technical_manager','emp4.name as technical_head')
    //         ->orderby('add_news.id','desc')
    //         ->get();
    
        $edit_data=Add_news::find($id);
        $property_type = Property :: all();
        $category = Category :: all();
        $tag = Tags :: all();
        $tags= Tags :: all();
        $location = Location :: all();
        $location1= Location :: all();

        $associatesbank=AssociatesBank::all();
        $product=Products::all();
        $area=Area::all();
        $emp=EmployeeRegistration::all();
        $data=Add_news::orderby('id','desc')->get();


// echo json_encode($tag);
// exit(); 
        $ongoing=New_Valuer::where('status','ongoing')
        ->leftjoin('locations','locations.id','=','new_valuer.location_id')
 ->select('new_valuer.*','locations.locations')
        ->orderby('new_valuer.id','desc')
        ->get();

        $com=New_Valuer::where('status','completed')
        ->leftjoin('locations','locations.id','=','new_valuer.location_id')
 ->select('new_valuer.*','locations.locations')
        ->orderby('new_valuer.id','desc')
        ->get();

        $cancelled=New_Valuer::where('status','cancelled')
        ->leftjoin('locations','locations.id','=','new_valuer.location_id')
 ->select('new_valuer.*','locations.locations')
        ->orderby('new_valuer.id','desc')
        ->get();

        $pending=New_Valuer::where('status','pending')
        ->leftjoin('locations','locations.id','=','new_valuer.location_id')
 ->select('new_valuer.*','locations.locations')
        ->orderby('new_valuer.id','desc')
        ->get();





        $new_edit = Add_news::find($id);
        
        
          
        // $new_edit = Add_news :: leftjoin('propertys','propertys.id','=','.property_type_id') 
        // ->leftjoin('categorys','categorys.id','=','new_valuer.category_id') 
        // ->leftjoin('tags','tags.id','=','new_valuer.tag_id')
        // ->leftjoin('locations','locations.id','=','new_valuer.location_id')
        // ->select('add_news.*','categorys.category','tags.tag','locations.locations','propertys.property')
        // ->get();



        
        $add_new = Add_news:: leftjoin('employee_registraions','employee_registraions.id','=','add_news.field_executive_id')
        ->leftjoin('locations','locations.id','=','add_news.location_id')
        ->select('add_news.*','employee_registraions.role_name_id','locations.locations')
        ->get();

        return view('FieldExecutive.new_valuation',compact('new','data','emp','area','product','associatesbank','edit_data','property_type','tag','category','location','new_edit','add_new','ongoing','com','cancelled','pending','location1','tags'));
    }

    public function create(Request $request)
    {
        // dd($request->all());
        $image_name_array=[];
        if (isset($request->image_files) and !empty($request->image_files)) {
            foreach ($request->image_files as $key => $image) {
            $extension= explode('/', mime_content_type($image))[1];
            $data = base64_decode(substr($image, strpos($image, ',') + 1));
            $imgname='fe'.rand(000,999).$key . time() . '.' .$extension;
            file_put_contents(public_path('images/FE-valuation') . '/' . $imgname, $data);
            $image_name_array[]=$imgname;
        }
    }
       
        $insert = New_Valuer::create([

            'name' => $request->name,
           'valuation_id'=> $request->valuation_id,
            'contact_no'  => $request-> contact_no,
            'property_type_id'  => $request-> property_type_id,
            'property_address'  => $request-> property_address,
            'address'  => $request-> address,
            'road_name'  => $request-> road_name,
            'colony'  => $request-> colony,
            'pin_code'  => $request-> pin_code,
            'landmark'  => $request-> landmark,
            'meter_no'  => $request-> meter_no,
            'plot_area'  => $request-> plot_area,
            'up_area'  => $request-> up_area,
            'GF'  => $request->  GF,
            'FF'  => $request-> FF,
            'SF'  => $request-> SF,
            'TF'  => $request-> TF,
            'occupancy_status'  => $request->occupancy_status, 
            'occupied_by'  => $request-> occupied_by,
            'four_borders'  => $request-> four_borders,
            'whether_boundaries_matching'  => $request-> whether_boundaries_matching,
            'rate_range'  => $request-> rate_range,
            'plot_range'  => $request-> plot_range,
            'road_type'  => $request-> road_type,
            'road_width_in_feet'  => $request-> road_width_in_feet,
            'type_of_structure'  => $request-> type_of_structure,
            'remark_on_boundaries_matching'  => $request-> remark_on_boundaries_matching,
            'lat'  => $request-> lat,
            'long'  => $request-> long,
            'construction_stage'  => $request-> construction_stage,
            'side_marginal_distance_in_feet'  => $request-> side_marginal_distance_in_feet,
            'discription_of_property'  => $request-> discription_of_property,
            'person_met_at_site'  => $request-> person_met_at_site,
            'relation_with_owner'  => $request-> relation_with_owner,
            'remark_on_property'  => $request-> remark_on_property,
            'deviation'  => $request-> deviation,
            'rate_referenace'  => $request-> rate_referenace,
            'date_of_visit'  => $request-> date_of_visit,
            'name_of_FE_visited_the_property_id'  => $request-> name_of_FE_visited_the_property,
            'location_id'  => $request-> location_id,
            'category_id'  => $request-> category_id,
            'tag_id'  => $request-> tag_id,
            'image'  => $image_name_array,
            'status'=>'ongoing',
            'reason'=>$request->reason,
            'last_updated_by'=>$request->last_updated_by
        ]);

        return Redirect()->route('FE.ongoingmodel')->with(['success' => true, 'message' => 'Data Successfully Submitted !']);

    }


    public function delete(Request $request)
    {
        $valuation = New_Valuer::where('id', $request->id)
            ->delete();
        return redirect()->back()->with(['success' => true, 'message' => 'Data Successfully Deleted !']);
    }



    public function edit($id)
    {
        //$edit_new = New_Valuer::find($id);
    // dd($edit_new);
        $edit_new = New_Valuer :: leftjoin('propertys','propertys.id','=','new_valuer.property_type_id') 
        ->leftjoin('categorys','categorys.id','=','new_valuer.category_id') 
        ->leftjoin('tags','tags.id','=','new_valuer.tag_id')
        ->leftjoin('locations','locations.id','=','new_valuer.location_id')
        ->leftjoin('employee_registraions','employee_registraions.id','=','new_valuer.name_of_FE_visited_the_property_id')
        ->select('new_valuer.*','categorys.category','tags.tag','locations.locations','propertys.property','employee_registraions.role_name_id')
        ->where('new_valuer.id',$id)
        ->first();
// echo json_encode($edit_new);
// exit();

        $property_type = Property :: all();
        $category = Category :: all();
        $tag = Tags :: all();
        $location = Location :: all();
        $employee_registraions = EmployeeRegistration :: all();

        // $new_edit = Add_news::find($id); 
        // $add_new = Add_news:: leftjoin('employee_registraions','employee_registraions.id','=','add_news.field_executive_id')
        // ->leftjoin('locations','locations.id','=','add_news.location_id')
        // ->select('add_news.*','employee_registraions.role','locations.locations')
        // ->get();
        return view('FieldExecutive.edit_new_valuation',compact('property_type','tag','category','location','edit_new'));
       
        
    }

    public function update(Request $request)
    {
        // $request->validate([
        //     'service' => 'required',
        // ]);
        
       
    $update = New_Valuer::where('id', $request->id)->first();
    
            $update -> name = $request->name;
            $update ->valuation_id= $request->valuation_id;
            $update -> contact_no  = $request-> contact_no;
            $update -> property_type_id  = $request-> property_type_id;
            $update -> property_address  = $request-> property_address;
            $update -> address  = $request-> address;
            $update -> road_name  = $request-> road_name;
            $update -> colony  = $request-> colony;
            $update -> pin_code  = $request-> pin_code;
            $update -> landmark  = $request-> landmark;
            $update -> meter_no = $request-> meter_no;
            $update -> plot_area  = $request-> plot_area;
            $update -> up_area  = $request-> up_area;
            $update -> GF  = $request->  GF;
            $update -> FF  = $request-> FF;
            $update -> SF  = $request-> SF;
            $update -> TF  = $request-> TF;
            $update -> occupancy_status  = $request->occupancy_status; 
            $update -> occupied_by = $request-> occupied_by;
            $update -> four_borders = $request-> four_borders;
            $update -> whether_boundaries_matching  = $request-> whether_boundaries_matching;
            $update -> rate_range = $request-> rate_range;
            $update -> plot_range  = $request-> plot_range;
            $update -> road_type  = $request-> road_type;
            $update -> road_width_in_feet  = $request-> road_width_in_feet;
            $update -> type_of_structure  = $request-> type_of_structure;
            $update -> remark_on_boundaries_matching  = $request-> remark_on_boundaries_matching;
            $update -> lat  = $request-> lat;
            $update -> long  = $request-> long;
            $update -> construction_stage  = $request-> construction_stage;
            $update -> side_marginal_distance_in_feet  = $request-> side_marginal_distance_in_feet;
            $update -> discription_of_property  = $request-> discription_of_property;
            $update -> person_met_at_site  = $request-> person_met_at_site;
            $update -> relation_with_owner  = $request-> relation_with_owner;
            $update -> remark_on_property  = $request-> remark_on_property;
            $update -> deviation  = $request-> deviation;
            $update -> rate_referenace  = $request-> rate_referenace;
            $update -> date_of_visit  = $request-> date_of_visit;
            $update -> name_of_FE_visited_the_property_id = $request-> name_of_FE_visited_the_property;
            $update -> location_id  = $request-> location_id;
            $update -> category_id  = $request-> category_id;
            $update -> tag_id  = $request-> tag_id;
            $update ->last_updated_by=$request->last_updated_by;

            $image_name_array=[];
            if (isset($request->image_files) and !empty($request->image_files)) {
                foreach ($request->image_files as $key => $image) {
                $extension= explode('/', mime_content_type($image))[1];
                $data = base64_decode(substr($image, strpos($image, ',') + 1));
                $imgname='fe'.rand(000,999).$key . time() . '.' .$extension;
                file_put_contents(public_path('images/FE-valuation') . '/' . $imgname, $data);
                $image_name_array[]=$imgname;
            }

            $update -> image  = $image_name_array;

        }
    

            $update->save();
      

       // dd($update);
        return redirect()->route('FE.ongoingmodel')->with(['success' => true, 'message' => 'Data Successfully Updated !']);
    }


}
