{{-- <html>
    <title></title>
    <head></head>
    <body>
        <h1>OppS!!.... somethings went wrong</h1>
    </body>
</html> --}}


<h1>OppS!!.... somethings went wrong</h1>